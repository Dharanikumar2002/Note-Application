package com.tcs.finalnotes3.presentation

import android.content.Context
import android.os.Bundle
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.findNavController
import com.carapps.notesapp.R
import com.carapps.notesapp.databinding.FragmentNoteDetailBinding
import com.tcs.finalnotes3.framework.database.Note
import com.tcs.finalnotes3.model.NoteViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Hilt can provide dependencies to other Android classes that have the @AndroidEntryPoint annotation:
//@AndroidEntryPoint, then you also must annotate Android classes that depend on it
//When annotate at fragment then must annotate at wherever they are using
//@AndroidEntryPoint generates an individual Hilt component for each Android class in your project.
// These components can receive dependencies from their respective parent classes
//here Parent class is HILTVIEW Model

@AndroidEntryPoint
class NoteDetailFragment : Fragment() {
    private var currentNote = Note(0, "", "", "")

    private var mBinding: FragmentNoteDetailBinding? = null
    private val binding get() = mBinding!!

    lateinit var note: Note

    private val viewModel: NoteViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        mBinding = FragmentNoteDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        Menu bar function set up
        initMenuProvider()

//        setting up the clicklsitner for check box

        binding.checkButton.setOnClickListener {

//            check whether note title and description is blank or not

            if (binding.noteTitle.text.toString() != "" || binding.noteText.text.toString() != "") {
                val time = System.currentTimeMillis()

//                using apply scope, setting the values
                currentNote.apply {

                    noteTitle=binding.noteTitle.text.toString()
                    description=binding.noteText.text.toString()
                    timeStamp=if(id.toLong() ==0L) time.toString() else timeStamp
                }
                if(currentNote.id.toLong() == 0L) {
                    currentNote.timeStamp = time.toString()

                }
                Toast.makeText(context, "Done!", Toast.LENGTH_SHORT).show()
                 hideKeyboard()
                saveEntry()
                findNavController().navigateUp()

            } else {
                findNavController().navigateUp()
            }
        }


//        if (requireArguments().get("id") != null) {
//            val id = requireArguments().get("id") as Int
//            viewModel.retrieveNote(id).let { selectedNote ->
//                note = selectedNote
//                bind(note)
//            }
//        }
//
//    }

//        retrives the Id argument using viewmodel and initilize the note and bind to UI using bind (using let)
        requireArguments().get("id")?.let { id ->
            if (id != 0) {
                viewModel.retrieveNote(id as Int).let { selectedNote ->
                    note = selectedNote
                    bind(note)
                }
            }
        }
    }

    private fun hideKeyboard() {
        val imm = context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.noteText.windowToken, 0)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        mBinding = null
    }

    private fun initMenuProvider() {

        val menuHost: MenuHost = requireActivity()

        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.item_detail_action_bar, menu)
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                when (menuItem.itemId) {
                    R.id.delete ->
                        if (::note.isInitialized) viewModel.deleteNote(note)
                }
                findNavController().navigateUp()
                return true
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }


    private fun bind(note: Note) {
        binding.apply {
            noteTitle.setText(note.noteTitle)
            noteText.setText(note.description)
        }
    }


    private fun saveEntry() {
        val noteTitle = binding.noteTitle.text.toString()
        val noteText = binding.noteText.text.toString()
        val noteTime = SimpleDateFormat("dd MMM, yyyy,HH:mm:ss", Locale.ENGLISH)
            .format(Date())
        if (viewModel.isEntryValid(noteTitle, noteText)) {
            if (::note.isInitialized) {
                viewModel.addOrUpdateNote(note.id, noteTitle, noteText, noteTime)
            } else {
                viewModel.addOrUpdateNote(id,noteTitle, noteText, noteTime)
            }
        }
    }
}
