package com.tcs.finalnotes3.di

import android.content.Context
import androidx.room.Room
import com.tcs.finalnotes3.framework.database.NoteDatabase
import com.tcs.finalnotes3.framework.repository.NoteRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

//    Installing a module into a component allows its bindings to be accessed as a dependency of other
//    bindings in that component or in any child component below it in the component hierarchy
//   SingletonComponent used for application level and Single Time instance creation

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Singleton
    @Provides
    fun providedDatabase(@ApplicationContext context: Context): NoteDatabase =
        Room.databaseBuilder(context, NoteDatabase::class.java, "note_database")
            .allowMainThreadQueries()
            .build()

    @Singleton
    @Provides
    fun providedNoteRepository(
        noteDatabase: NoteDatabase
    ): NoteRepository = NoteRepositoryImpl(noteDatabase)

}
