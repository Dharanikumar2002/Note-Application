package com.tcs.finalnotes3.presentation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.carapps.notesapp.databinding.FragmentNotesBinding
import com.tcs.finalnotes3.model.NoteViewModel
import com.tcs.finalnotes3.model.adapters.NoteAdapter
import dagger.hilt.android.AndroidEntryPoint
// Hilt can provide dependencies to other Android classes that have the @AndroidEntryPoint annotation:
//@AndroidEntryPoint, then you also must annotate Android classes that depend on it
//When annotate at fragment then must annotate at wherever they are using

//@AndroidEntryPoint generates an individual Hilt component for each Android class in your project.
// These components can receive dependencies from their respective parent classes
//here Parent class is HILTVIEW Model


@AndroidEntryPoint
class NotesFragment : Fragment() {

    private lateinit var binding: FragmentNotesBinding
    private val viewModel: NoteViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = FragmentNotesBinding.inflate(inflater).also { binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        Create the adapter for RecyclerView
        val adapter = NoteAdapter {

//            Defining action navigate to notedetailfragment

            val action =
                NotesFragmentDirections.actionNoteListFragmentToNoteDetailFragment()
//            passing the specific id
            val bundle = bundleOf("id" to it.id)
            this.findNavController().navigate(action.actionId, bundle)

        }

//        sets the adapter to recyclerview
        binding.recyclerView.adapter = adapter


//observes the livedata from the viewmodel and collects
        lifecycleScope.launchWhenCreated {
            viewModel.notes.collect { adapter.submitList(it) }
        }

//        setting the click listner of floating action bar to navigate to noteFragmentdetail
            binding.fab.setOnClickListener {
                val action =
                    NotesFragmentDirections.actionNoteListFragmentToNoteDetailFragment()
                findNavController().navigate(action)

        }

    }
}
