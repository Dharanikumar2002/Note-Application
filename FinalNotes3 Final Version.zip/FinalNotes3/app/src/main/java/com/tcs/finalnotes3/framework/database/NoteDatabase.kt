package com.tcs.finalnotes3.framework.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.tcs.finalnotes3.framework.database.Note
import com.tcs.finalnotes3.framework.database.NoteDao

@Database(entities = [Note::class], version = 1, exportSchema = false)

abstract class NoteDatabase : RoomDatabase() {

    abstract fun noteDao(): NoteDao
}
