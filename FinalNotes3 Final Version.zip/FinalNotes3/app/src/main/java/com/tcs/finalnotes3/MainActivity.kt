package com.tcs.finalnotes3

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupActionBarWithNavController
import com.carapps.notesapp.R
import com.carapps.notesapp.databinding.ActivityMainBinding

import dagger.hilt.android.AndroidEntryPoint

// Hilt can provide dependencies to other Android classes that have the @AndroidEntryPoint annotation:
//@AndroidEntryPoint, then you also must annotate Android classes that depend on it
//When annotate at fragment then must annotate at wherever they are using
//@AndroidEntryPoint generates an individual Hilt component for each Android class in your project.
// These components can receive dependencies from their respective parent classes
//here Parent class is HILTVIEW Model

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var mBinding : ActivityMainBinding
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mBinding.root)



//        Sets the toolbar from the layout as the action bar
        setSupportActionBar(mBinding.toolbar)

//        Finds the Navhostfragment using support manager
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment

//        Initializes the navcontroller with Navhostfragment\
        navController = navHostFragment.navController

//        SetUp the action bar
        setupActionBarWithNavController(navController)
    }

//Attempts to navigate up using navcontroller,if it doesnot goes successfully,return backs to onsuuportNavigatesetup again
    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}

