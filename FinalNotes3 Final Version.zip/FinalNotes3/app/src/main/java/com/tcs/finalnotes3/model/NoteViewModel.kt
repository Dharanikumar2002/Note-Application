package com.tcs.finalnotes3.model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tcs.finalnotes3.framework.database.Note
import com.tcs.finalnotes3.framework.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import javax.inject.Inject

//class to be injected by Hilt
//Here we are using Hiltviewmodel class,so that whatever classes are using viewmodel class they required to
//annotate with anroidenrtypoint ,to create instances

@HiltViewModel
class NoteViewModel
@Inject constructor(private val noteRepository: NoteRepository) : ViewModel() {

    var notes: Flow<List<Note>> = noteRepository.getNotes()

    private fun insertOrUpdateNote(note: Note) {
        viewModelScope.launch {
            noteRepository.insertOrUpdate(note)
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            noteRepository.delete(note)
        }
    }

    fun retrieveNote(id: Int) = noteRepository.getNote(id)

    fun addOrUpdateNote(noteId: Int, noteTitle: String, noteText: String, noteTime: String) {
        val note = if (noteId == 0) {
            Note(id = 0, noteTitle = noteTitle, description = noteText, timeStamp = noteTime)
        } else {
            Note(id = noteId, noteTitle = noteTitle, description = noteText, timeStamp = noteTime)
        }
        insertOrUpdateNote(note)
    }

    fun isEntryValid(noteTitle: String, noteText: String): Boolean {
        return noteTitle.isNotBlank() && noteText.isNotBlank()
    }
}