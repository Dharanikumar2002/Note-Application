package com.tcs.finalnotes3.framework.usecase

import com.tcs.finalnotes3.framework.database.Note
import com.tcs.finalnotes3.framework.repository.NoteRepository
import javax.inject.Inject

class AddNoteUseCase
@Inject constructor(private val noteRepository: NoteRepository)
{
    suspend fun invoke(note: Note) {
        noteRepository.insert(note)
    }
}
