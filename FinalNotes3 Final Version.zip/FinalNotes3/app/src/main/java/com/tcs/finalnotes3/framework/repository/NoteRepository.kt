package com.tcs.finalnotes3.framework.repository

import kotlinx.coroutines.flow.Flow
import com.tcs.finalnotes3.framework.database.Note

interface NoteRepository {

    suspend fun insert(note: Note)

    suspend fun update(note: Note)

    suspend fun delete(note: Note)

    fun getNotes():Flow<List<Note>>

    fun getNote(id: Int): Note

    suspend fun insertOrUpdate(note: Note)


}

