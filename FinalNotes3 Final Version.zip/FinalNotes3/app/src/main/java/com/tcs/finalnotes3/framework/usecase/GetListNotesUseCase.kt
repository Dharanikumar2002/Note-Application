package com.tcs.finalnotes3.framework.usecase

import com.tcs.finalnotes3.framework.database.Note
import com.tcs.finalnotes3.framework.repository.NoteRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetListNotesUseCase
@Inject constructor(private val noteRepository: NoteRepository) {
    fun invoke(): Flow<List<Note>> {
        return noteRepository.getNotes()
    }
}
