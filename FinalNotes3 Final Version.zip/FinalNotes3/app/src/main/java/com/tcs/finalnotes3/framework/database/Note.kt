package com.tcs.finalnotes3.framework.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable


@Entity
data class Note(

    @PrimaryKey(autoGenerate = true)
    val id: Int,

    @ColumnInfo(name = "title")
    var noteTitle: String,

    @ColumnInfo(name = "description")
    var description: String,

    @ColumnInfo(name = "time")
    var timeStamp: String
)